﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace EfCoreTest.Tests
{
    public class DbFixture
    {
        public ServiceProvider ServiceProvider { get; private set; }

        public DbFixture()
        {
            ServiceCollection? serviceCollection = new();

            //string cnx = "Server=localhost;Database=Biere_BDD;user id=sa;password=****";
            string cnx = "Server=localhost;Database=Biere_BDD;Trusted_Connection=True;";

            serviceCollection
                .AddDbContext<BeerContext.BeerContext>(options => options.UseSqlServer(cnx),
                    ServiceLifetime.Transient);

            ServiceProvider = serviceCollection.BuildServiceProvider();
        }
    }
}
