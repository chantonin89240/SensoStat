﻿using EfCoreTest.Queries;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using Xunit;

namespace EfCoreTest.Tests
{
    public class LVL2Tests : IClassFixture<DbFixture>
    {
        private readonly ServiceProvider _serviceProvider;

        public LVL2Tests(DbFixture fixture)
        {
            _serviceProvider = fixture.ServiceProvider;
        }

        [Fact]
        public void GetBrandCountry()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<KeyValuePair<string, string>>? result = new LVL2(context).GetBrandCountry();
        }

        [Fact]
        public void GetRegionsWithoutBrasseries()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<string>? result = new LVL2(context).GetRegionsWithoutBrasseries();
        }

        [Fact]
        public void GetAllBrandWithFullColors()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<string>? result = new LVL2(context).GetAllBrandWithFullColors();
        }

        [Fact]
        public void GetAllBeersNameByRegion()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<KeyValuePair<string, List<string>>>? result = new LVL2(context).GetAllBeersNameByRegion();
        }

        [Fact]
        public void GetNumberOfBeerByRegion()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            dynamic result = new LVL2(context).GetNumberOfBeerByRegion();
        }
    }
}
