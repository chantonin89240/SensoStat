﻿using EfCoreTest.Queries;
using EfCoreTest.Queries.Models;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using Xunit;

namespace EfCoreTest.Tests
{
    public class LVL1Tests : IClassFixture<DbFixture>
    {
        private readonly ServiceProvider _serviceProvider;

        public LVL1Tests(DbFixture fixture)
        {
            _serviceProvider = fixture.ServiceProvider;
        }

        [Fact]
        public void GetBrasserieCity()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<KeyValuePair<string, string>>? result = new LVL1(context).GetBrasserieCity();
        }

        [Fact]
        public void GetBrasserieNameByCity()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<string>? result = new LVL1(context).GetBrasserieNameByCity();
        }

        [Fact]
        public void GetBrasserieNameByRegion()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<string>? result = new LVL1(context).GetBrasserieNameByRegion();
        }

        [Fact]
        public void GetCountryByProducerSize()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<KeyValuePair<string, double?>>? result = new LVL1(context).GetCountryByProducerSize();
        }

        [Fact]
        public void GetTypesOfBeers()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<string>? result = new LVL1(context).GetTypesOfBeers();
        }

        [Fact]
        public void GetChimayAllVersions()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<GenericStringModel> result = new LVL1(context).GetChimayAllVersions();
        }

        [Fact]
        public void GetFrenchRegionMenufacturer()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<string>? result = new LVL1(context).GetFrenchRegionMenufacturer();
        }

        [Fact]
        public void GetBrasserieByRegionForFrenchManufacturer()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<GenericStringModel> result = new LVL1(context).GetBrasserieByRegionForFrenchManufacturer();
        }

        [Fact]
        public void GetBeerBetween5And6Degrees()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<string>? result = new LVL1(context).GetBeerBetween5And6Degrees();
        }

        [Fact]
        public void GetBestConsomation()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            KeyValuePair<string, double?> result = new LVL1(context).GetBestConsomation();
        }

        [Fact]
        public void GetLesserConsomation()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            KeyValuePair<string, double?> result = new LVL1(context).GetLesserConsomation();
        }

        [Fact]
        public void GetHeinekenBrasserie()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            string? result = new LVL1(context).GetHeinekenBrasserie();
        }
    }
}
