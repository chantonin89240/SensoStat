﻿using EfCoreTest.Queries;
using EfCoreTest.Queries.Models;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using Xunit;

namespace EfCoreTest.Tests
{
    public class LVL3Tests : IClassFixture<DbFixture>
    {
        private readonly ServiceProvider _serviceProvider;

        public LVL3Tests(DbFixture fixture)
        {
            _serviceProvider = fixture.ServiceProvider;
        }

        [Fact]
        public void GetRepartition()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<RepartitionType>? result = new LVL3(context).GetRepartition();
        }

        [Fact]
        public void GetBrasseriesAllColors()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<string>? result = new LVL3(context).GetBrasseriesAllColors();
        }

        [Fact]
        public void GetBrasseriesAllColorsV2()
        {
            using BeerContext.BeerContext? context = _serviceProvider.GetService<BeerContext.BeerContext>();
            List<string>? result = new LVL3(context).GetBrasseriesAllColorsV2();
        }
    }
}