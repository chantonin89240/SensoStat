﻿using EfCoreTest.Queries.Models;

namespace EfCoreTest.Queries
{
    public class LVL3
    {
        private readonly BeerContext.BeerContext _context;

        public LVL3(BeerContext.BeerContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Proportion des types de bières par pays
        /// </summary>
        /// <returns></returns>
        public List<RepartitionType> GetRepartition()
        {
            return _context.Biere.GroupBy(b => new { b.Marque.Brasserie.Region.NomPays, b.Type.NomType })
                .Select(p => new RepartitionType
                {
                    NomPays = p.Key.NomPays,
                    NomType = p.Key.NomType,
                    Pourcentage = (double)p.Count() /
                        _context.Biere.Where(b => b.Marque.Brasserie.Region.NomPays == p.Key.NomPays)
                        .Count()

                })
                .ToList();
        }

        /// <summary>
        /// Quelles sont les brasseries qui produisent toutes les couleurs de bières V2
        /// </summary>
        /// <returns></returns>
        public List<string> GetBrasseriesAllColors()
        {
            return _context.Brasserie.Where(
            b => _context.Biere.Select(bi => bi.CouleurBiere)
             .Distinct()
             .All(couleur => b.Marque.Any(
                        m => m.Biere.Any(bier => bier.CouleurBiere == couleur)
                    )
                  )
             )
             .Select(b => b.NomBrasserie)
             .ToList();
        }

        /// <summary>
        /// Quelles sont les brasseries qui produisent toutes les couleurs de bières V2
        /// </summary>
        /// <returns></returns>
        public List<string> GetBrasseriesAllColorsV2()
        {
            //Avec une version différente
            var couleurBiere = _context.Biere.GroupBy(x => x.CouleurBiere).Select(x => x.Key);
            return _context.Brasserie.Where(
                   x => !couleurBiere.Except(
                       x.Marque.SelectMany(z => z.Biere)
                       .GroupBy(z => z.CouleurBiere)
                       .Select(z => z.Key)
                   ).Any()
               ).Select(b => b.NomBrasserie)
               .ToList();
        }
    }
    
}