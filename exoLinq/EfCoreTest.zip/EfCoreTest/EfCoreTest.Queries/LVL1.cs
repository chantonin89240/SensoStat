﻿using EfCoreTest.Queries.Models;

namespace EfCoreTest.Queries
{
    public class LVL1
    {
        private readonly BeerContext.BeerContext _context;

        public LVL1(BeerContext.BeerContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Afficher pour chaque brasserie la ville
        /// </summary>
        /// <returns></returns>
        public List<KeyValuePair<string, string>> GetBrasserieCity()
        {
            return _context.Brasserie
                .Select(b => new KeyValuePair<string, string>(b.NomBrasserie, b.Ville))
                .ToList();
        }

        /// <summary>
        /// Afficher toutes les brasseries de Dijon
        /// </summary>
        /// <returns></returns>
        public List<string> GetBrasserieNameByCity()
        {
            return _context.Brasserie
                .Where(b => b.Ville == "Dijon")
                .Select(b => b.NomBrasserie)
                .ToList();
        }

        /// <summary>
        /// Afficher les brasseries de la region Bourgogne
        /// </summary>
        /// <returns></returns>
        public List<string> GetBrasserieNameByRegion()
        {
            return _context.Brasserie
                .Where(b => b.NomRegion == "Bourgogne")
                .Select(b => b.NomBrasserie)
                .ToList();
        }

        /// <summary>
        /// Afficher les couleurs de bieres
        /// </summary>
        /// <returns></returns>
        public List<string> GetAllBeerColors()
        {
            return _context.Biere
                .Select(b => b.CouleurBiere)
                .Distinct()
                .ToList();
        }

        /// <summary>
        /// Listez les pays du plus grand au plus petit producteur(NomPays, Production)
        /// </summary>
        /// <returns></returns>
        public List<KeyValuePair<string, double?>> GetCountryByProducerSize()
        {
            return _context.Pays.OrderByDescending(p => p.Production)
                .Select(p => new KeyValuePair<string, double?>(p.NomPays, p.Production))
                .ToList();
        }

        /// <summary>
        /// Listez les types de bières
        /// </summary>
        /// <returns></returns>
        public List<string> GetTypesOfBeers()
        {
            return _context.Type
                .Distinct()
                .Select(t => t.NomType)
                .ToList();
        }

        /// <summary>
        /// Il existe une bière nommée Chimay, dans quelle version et quelle couleur peut-on la trouver(NomMarque , Version, CouleurBière)
        /// </summary>
        /// <returns></returns>
        public List<GenericStringModel> GetChimayAllVersions()
        {
            return _context.Biere
                .Where(b => b.NomMarque == "Chimay")
                .Select(b => new GenericStringModel
                {
                    Value1 = b.NomMarque.Trim(),
                    Value2 = b.Version.Trim(),
                    Value3 = b.CouleurBiere.Trim()
                })
                .ToList();
        }

        /// <summary>
        /// En France quelles régions fabriquent de la bière ?
        /// </summary>
        /// <returns></returns>
        public List<string> GetFrenchRegionMenufacturer()
        {
            return _context.Region
                .Where(r => r.NomPays == "France")
                .Select(x => x.NomRegion)
                .Distinct()
                .ToList();
        }

        /// <summary>
        /// Où puis-je aller pour boire de la bonne bière française dans ces régions(NomBrasserie, Ville, NomRegion)
        /// </summary>
        /// <returns></returns>
        public List<GenericStringModel> GetBrasserieByRegionForFrenchManufacturer()
        {
            return _context.Biere
                .Where(b => b.Marque.Brasserie.Region.NomPays == "France")
                .Select(b => new GenericStringModel
                {
                    Value1 = b.Marque.Brasserie.NomBrasserie,
                    Value2 = b.Marque.Brasserie.Ville,
                    Value3 = b.Marque.Brasserie.NomRegion
                })
                .ToList();
        }

        /// <summary>
        /// Les bières blondes avec un taux d’alcool compris entre 5 et 6 sont fortement appréciées.
        /// </summary>
        /// <returns></returns>
        public List<string> GetBeerBetween5And6Degrees()
        {
            return _context.Biere
                .Where(b => b.TauxAlcool >= 5 && b.TauxAlcool <= 6)
                .Select(b => b.Version)
                .ToList();
        }

        /// <summary>
        /// Quelle est la plus forte consommation de bière ? 
        /// </summary>
        /// <returns></returns>
        public KeyValuePair<string, double?> GetBestConsomation()
        {
            return _context.Pays
                .OrderByDescending(p => p.Consommation)
                .Select(p => new KeyValuePair<string, double?>(p.NomPays, p.Consommation))
                .First();
        }


        /// <summary>
        /// Quelle est la consommation la plus faible?
        /// </summary>
        /// <returns></returns>
        public KeyValuePair<string, double?> GetLesserConsomation()
        {
            return _context.Pays
                .OrderBy(p => p.Consommation)
                .Select(p => new KeyValuePair<string, double?>(p.NomPays, p.Consommation))
                .First();
        }

        /// <summary>
        /// Quelle est la brasserie dont le nom est composé avec « Heineken » ?
        /// </summary>
        /// <returns></returns>
        public string? GetHeinekenBrasserie()
        {
            return _context.Brasserie
                .Where(b => b.NomBrasserie.Contains("Heineken"))
                .Select(b => b.NomBrasserie)
                .FirstOrDefault();
        }
    }
}
