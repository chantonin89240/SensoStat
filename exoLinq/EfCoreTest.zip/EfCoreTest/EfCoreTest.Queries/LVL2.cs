﻿namespace EfCoreTest.Queries
{
    public class LVL2
    {
        private readonly BeerContext.BeerContext _context;

        public LVL2(BeerContext.BeerContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Pour chaque marque, le nom du pays
        /// </summary>
        /// <returns></returns>
        public List<KeyValuePair<string, string>> GetBrandCountry()
        {
            return _context.Marque
                .Select(m => new KeyValuePair<string, string>(m.NomMarque, m.Brasserie.Region.NomPays))
                .ToList();
        }

        /// <summary>
        /// Quelles sont les regions sans brasseries
        /// </summary>
        /// <returns></returns>
        public List<string> GetRegionsWithoutBrasseries()
        {
            #region Solution 1
            //List<string>? regions = _context.Region
            //        .Distinct()
            //        .Select(r => r.NomRegion)
            //        .ToList();

            //List<string>? regionsBrasseries = _context.Brasserie
            //    .Select(x => x.NomRegion)
            //    .Distinct().ToList();

            //return regions.Except(regionsBrasseries).ToList();
            #endregion

            #region Solution 2
            //List<string>? regionsBrasseries = _context.Brasserie
            //        .Select(r => r.NomRegion)
            //        .Distinct()
            //        .ToList();


            //List<string>? regions = _context.Region.
            //    Select(b => b.NomRegion)
            //    .Where(b => !regionsBrasseries.Contains(b))
            //    .Distinct()
            //    .ToList();
            #endregion

            #region Solution 3
            List<string>? regions = _context.Region
                .Select(b => b.NomRegion)
                .Except(_context.Brasserie.Select(s => s.NomRegion).Distinct())
                .ToList();
            #endregion

            return regions;
        }

        /// <summary>
        /// Quelles sont les marques qui ont toutes les couleurs de biere
        /// </summary>
        /// <returns></returns>
        public List<string> GetAllBrandWithFullColors()
        {
            IQueryable<string>? couleurBiere = _context.Biere.GroupBy(x => x.CouleurBiere).Select(x => x.Key);

            return _context.Brasserie.Where(
                   x => !couleurBiere.Except(
                       x.Marque.SelectMany(z => z.Biere)
                       .GroupBy(z => z.CouleurBiere)
                       .Select(z => z.Key)
                   ).Any()
               ).Select(b => b.NomBrasserie).ToList();
        }


        /// <summary>
        /// Afficher le nom des bieres par régions
        /// </summary>
        /// <returns></returns>
        public List<KeyValuePair<string, List<string>>> GetAllBeersNameByRegion()
        {
            return _context.Biere
                .GroupBy(b => b.Marque.Brasserie.NomRegion)
                .Select(b => new KeyValuePair<string, List<string>>(b.Key, b.Select(s => s.Version).ToList()))
                .ToList();
        }

        /// <summary>
        /// Afficher le nombre de bieres par pays
        /// </summary>
        /// <returns></returns>
        public dynamic GetNumberOfBeerByRegion()
        {
            return _context.Biere.GroupBy(b => b.Marque.Brasserie.NomRegion)
                .Select(b => new
                {
                    b.Key,
                    Value = b.Count()
                }).OrderBy(b => b.Key);
        }
    }
}
