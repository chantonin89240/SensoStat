﻿namespace EfCoreTest.Queries.Models
{
    public class RepartitionType
    {
        public string? NomPays { get; set; }
        public string? NomType { get; set; }
        public double Pourcentage { get; set; }
    }
}
